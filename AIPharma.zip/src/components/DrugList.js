import React, { useEffect, useState } from 'react';

export default function DrugList() {
  const [drugs, setDrugs] = useState([]);

  const fetchDrugs = async () => {
    const res = await fetch(`${process.env.REACT_APP_API_URL}/api/drugs`);
    const data = await res.json();
    setDrugs(data);
  };

  useEffect(() => {
    fetchDrugs();
  }, []);

  return (
    <div style={{ margin: '2rem auto', maxWidth: 800 }}>
      <h2>📦 Current Inventory</h2>
      {drugs.length === 0 ? (
        <p>No drugs found.</p>
      ) : (
        <table border="1" cellPadding="8" style={{ width: '100%', textAlign: 'left' }}>
          <thead style={{ background: '#FFD700', color: '#000' }}>
            <tr>
              <th>Name</th>
              <th>Brand</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Expiry</th>
              <th>Batch</th>
            </tr>
          </thead>
          <tbody>
            {drugs.map((drug, idx) => (
              <tr key={idx}>
                <td>{drug.name}</td>
                <td>{drug.brand}</td>
                <td>{drug.quantity}</td>
                <td>{drug.price}</td>
                <td>{new Date(drug.expiryDate).toLocaleDateString()}</td>
                <td>{drug.batchNumber}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
