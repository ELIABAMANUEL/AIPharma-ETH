import React, { useEffect, useState } from 'react';

export default function SaleForm() {
  const [drugs, setDrugs] = useState([]);
  const [drugId, setDrugId] = useState('');
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchDrugs = async () => {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/drugs`);
      const data = await res.json();
      setDrugs(data);
      if (data.length > 0) setDrugId(data[0]._id); // Auto-select first drug
    };
    fetchDrugs();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch(`${process.env.REACT_APP_API_URL}/api/sales`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ drugId, quantity })
    });
    if (res.ok) {
      alert('✅ Sale recorded!');
    } else {
      const { error } = await res.json();
      alert(`❌ Error: ${error}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '2rem auto', maxWidth: 600 }}>
      <h2>💸 Record a Sale</h2>
      <label>
        Drug:
        <select value={drugId} onChange={(e) => setDrugId(e.target.value)}>
          {drugs.map((drug) => (
            <option key={drug._id} value={drug._id}>
              {drug.name} ({drug.quantity} in stock)
            </option>
          ))}
        </select>
      </label>
      <br />
      <label>
        Quantity:
        <input
          type="number"
          min="1"
          value={quantity}
          onChange={(e) => setQuantity(parseInt(e.target.value))}
        />
      </label>
      <br />
      <button type="submit" style={{ marginTop: '1rem' }}>Submit Sale</button>
    </form>
  );
}
