import React, { useState } from 'react';

export default function InteractionChecker() {
  const [input, setInput] = useState('');
  const [interactions, setInteractions] = useState([]);

  const check = async (e) => {
    e.preventDefault();
    const drugNames = input.split(',').map(d => d.trim());
    const res = await fetch(`${process.env.REACT_APP_API_URL}/api/check-interactions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ drugNames })
    });
    const data = await res.json();
    setInteractions(data.interactions);
  };

  return (
    <div style={{ margin: '2rem auto', maxWidth: 600 }}>
      <h2>🔬 Check Drug Interactions</h2>
      <form onSubmit={check}>
        <input
          type="text"
          placeholder="Enter drug names, separated by commas"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          style={{ width: '100%' }}
        />
        <button type="submit" style={{ marginTop: '1rem' }}>Check</button>
      </form>
      {interactions.length > 0 && (
        <ul style={{ marginTop: '1rem' }}>
          {interactions.map((i, idx) => (
            <li key={idx} style={{ color: 'red' }}>{i}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
