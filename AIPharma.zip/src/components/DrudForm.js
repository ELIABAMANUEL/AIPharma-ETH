import React, { useState } from 'react';

export default function DrugForm() {
  const [drug, setDrug] = useState({
    name: '',
    brand: '',
    quantity: 0,
    price: 0,
    expiryDate: '',
    batchNumber: ''
  });

  const handleChange = (e) => {
    setDrug({ ...drug, [e.target.name]: e.target.value });
  };

  const submit = async (e) => {
    e.preventDefault();
    await fetch(`${process.env.REACT_APP_API_URL}/api/drugs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(drug)
    });
    alert('✅ Drug added successfully!');
    setDrug({ name: '', brand: '', quantity: 0, price: 0, expiryDate: '', batchNumber: '' });
  };

  return (
    <form onSubmit={submit} style={{ margin: '1rem auto', maxWidth: 600 }}>
      <h2>Add New Drug</h2>
      <input name="name" placeholder="Name" value={drug.name} onChange={handleChange} required />
      <input name="brand" placeholder="Brand" value={drug.brand} onChange={handleChange} />
      <input name="quantity" type="number" placeholder="Quantity" value={drug.quantity} onChange={handleChange} />
      <input name="price" type="number" placeholder="Price" value={drug.price} onChange={handleChange} />
      <input name="expiryDate" type="date" value={drug.expiryDate} onChange={handleChange} />
      <input name="batchNumber" placeholder="Batch #" value={drug.batchNumber} onChange={handleChange} />
      <button type="submit" style={{ marginTop: '1rem' }}>Add Drug</button>
    </form>
  );
}
