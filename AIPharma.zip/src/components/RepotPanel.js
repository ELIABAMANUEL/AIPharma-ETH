import React, { useEffect, useState } from 'react';

export default function ReportPanel() {
  const [salesReport, setSalesReport] = useState(null);
  const [lowStock, setLowStock] = useState([]);
  const [expiring, setExpiring] = useState([]);

  useEffect(() => {
    fetch(`${process.env.REACT_APP_API_URL}/api/reports/daily-sales`)
      .then(res => res.json())
      .then(setSalesReport);

    fetch(`${process.env.REACT_APP_API_URL}/api/reports/low-stock`)
      .then(res => res.json())
      .then(setLowStock);

    fetch(`${process.env.REACT_APP_API_URL}/api/reports/expiring`)
      .then(res => res.json())
      .then(setExpiring);
  }, []);

  return (
    <div style={{ maxWidth: 800, margin: '2rem auto' }}>
      <h2>📊 Daily Reports</h2>

      {salesReport && (
        <>
          <p>Total Sales Today: {salesReport.total} ETB</p>
          <p>Transactions: {salesReport.sales.length}</p>
        </>
      )}

      <h3 style={{ marginTop: '1.5rem' }}>⚠️ Low Stock</h3>
      {lowStock.length === 0 ? (
        <p>All stocks are okay!</p>
      ) : (
        <ul>
          {lowStock.map((item, i) => (
            <li key={i}>
              {item.name} ({item.quantity} left)
            </li>
          ))}
        </ul>
      )}

      <h3 style={{ marginTop: '1.5rem' }}>⏰ Expiring Soon</h3>
      {expiring.length === 0 ? (
        <p>No drugs expiring within 30 days.</p>
      ) : (
        <ul>
          {expiring.map((item, i) => (
            <li key={i}>
              {item.name} → expires {new Date(item.expiryDate).toLocaleDateString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
