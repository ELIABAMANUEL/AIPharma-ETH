import React from 'react';
import DrugForm from './components/DrugForm';
import DrugList from './components/DrugList';
import SaleForm from './components/SaleForm';
import ReportPanel from './components/ReportPanel';
import InteractionChecker from './components/InteractionChecker';
import logo from './assets/logo.png';

const App = () => (
  <div style={{ fontFamily: 'sans-serif', textAlign: 'center' }}>
    <header style={{ background: '#111', color: '#FFD700', padding: '1rem' }}>
      <img src={logo} alt="AI Pharmacare Logo" style={{ height: 50 }} />
      <h1>AI Pharmacare</h1>
    </header>
    <main>
      <DrugForm />
      <DrugList />
      <SaleForm />
      <ReportPanel />
      <InteractionChecker />
    </main>
  </div>
);

export default App;
